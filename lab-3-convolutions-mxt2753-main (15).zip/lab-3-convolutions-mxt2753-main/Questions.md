# Part 1: Basic 2D Convolution

1. Based on your analysis using the Visual Profiler, what are the performance characteristics of the baseline 2D convolutional kernel?

   When I ran the basic convolution kernel through Nsight Compute, the first thing that stood out was how underwhelming the
performance was. The kernel only took 5.38 microseconds to run, which sounds fast at first, but when you look at how poorly the hardware is being used, it makes sense. The occupancy was just 14.47 percent, even though the theoretical max was 100 percent. So most of the GPU resources were just sitting there not doing anything useful. Memory throughput was at 9.02 and compute throughput was only 4.43, which tells me we weren’t really pushing the device at all. The profiler also pointed out that this kernel was causing over 49 thousand excessive global memory accesses because of uncoalesced loads. That was more than half of all global memory transactions, which is just incredibly inefficient. The L1 cache hit rate was decent at 84.15 percent, but the L2 cache hit rate dropped to 41.66 percent, so a lot of memory accesses went all the way out to slower global memory. The memory access pattern really wasn’t optimized.


2. What are the performance bottlenecks?

    Memory was by far the biggest problem. Each thread was reading from global memory even when neighboring threads needed the
exact same data. The memory accesses were uncoalesced, which made the situation worse. Warp stalls were also a huge issue. According to the warp state analysis, the kernel spent around 5.3 cycles per warp just sitting there waiting on memory to come back. That was actually over 50 percent of the total cycles between instructions, so memory latency completely dominated the execution. On top of that, the kernel only launched 36 blocks total, which is way too few for a GPU with 46 SMs. That small grid size left most of the GPU idle, which added to the low occupancy.

3. What are the potential optimizations that can be made to the kernel?

   There are a few things I’d change right away. First, the filter should be moved into constant memory. It’s small and reused by
all threads, so it’s a perfect candidate. That alone would cut down on redundant global reads. Next, shared memory needs to be added for the input image tiles. Right now, every thread loads overlapping pixel regions by itself, which is wasting bandwidth. If we cache those shared values within each block, that would reduce global memory traffic a lot. I’d also fix the grid configuration so that we launch more blocks and take better advantage of the GPU’s resources. Finally, I’d change how memory is accessed to make sure reads are coalesced. That would improve both throughput and reduce those stalls caused by memory dependencies.

# Part 2: Optimizing the Filter Access

1. Compared to the baseline kernel, what measureable performance improvements did you achieve with the optimized kernel? Give as much detail as possible (execution time, memory usage, etc.).

    In this version of the kernel, I moved the filter into constant memory instead of reading it from global memory like before
At first glance, the execution time stayed about the same, only dropping from 5.38 microseconds to 5.34, which isn't a huge deal. But the real improvements show up when looking at the memory behavior. Memory throughput increased from 11.23 percent in the baseline to 14.14 percent, which is actually a decent improvement. Compute throughput also went up a little, from 4.43 to 4.47. What really changed is how the kernel handles the filter. Now that it's using constant memory, those values are read way more efficiently and don't eat up global memory bandwidth.

2. What are the performance bottlenecks of the optimized kernel? Are any of them the same as the baseline kernel?

    The filter is optimized now, but the input image still isn't. All the pixel values are still being pulled from global memory
and the access pattern hasn’t changed. The L2 cache hit rate actually dropped a bit to 38.7 percent, and the memory chart still shows uncoalesced accesses with 67 percent of sectors being excessive. So even though the filter reads were cleaned up, the kernel is still spending a lot of time on slow memory accesses. There are still long scoreboard stalls too. Warps are waiting about 4.6 cycles on average before they can continue. That's better than the 5.3 cycles from the baseline, but it's still a major source of wasted time. Occupancy is still low at 13.8 percent, and the launch configuration wasn’t updated, so a lot of the GPU is still underutilized.

3. Which bottlenecks, if any, were improved by this kernel?

    The biggest win here is that the filter is no longer causing global memory traffic. By putting it in constant memory, every
thread is able to access it through a fast, cached path without wasting bandwidth. That definitely helped increase overall memory throughput and probably contributed to a small improvement in stall cycles too. It’s a good step in the right direction, but it didn’t fix the bigger memory problems related to the input data. That’s something I’ll need to deal with next using shared memory.

# Part 3: Tiled 2D Convolution

1. Compared to the baseline and optimized kernels, what measureable performance improvements did you achieve with the tiled kernel? Give as much detail as possible (execution time, memory usage, etc.).

   So this version didn’t make the program run faster in terms of execution time. In fact, the runtime actually increased to 8.29
microseconds, which is slower than both the baseline version at 5.38 and the constant memory one at 5.34. But the real value of this tiled kernel shows up in how it handles memory. By loading tiles of the input into shared memory, it significantly reduced the number of global memory reads. This helped bring down uncoalesced global memory accesses to 8,637, which is a huge drop from the 49,173 in the original version. Shared memory use also jumped a lot, which you can see from the 12.75K shared memory instructions issued. Compute throughput improved slightly to 8.77 percent, meaning the GPU is spending a little more of its time actually doing math rather than waiting around on memory
 
2. What are the performance bottlenecks of the optimized kernel? Are any of them the same as the baseline kernel?

    Some issues from earlier versions are still sticking around. Occupancy is still pretty low, sitting at only 16.3 percent, so
most of the GPU cores aren’t being used. On top of that, the average stall time between instructions is still high at 6 cycles, caused by scoreboard stalls. That’s not great, and it’s something we also saw in the previous versions. One new problem that showed up here is shared memory inefficiency. This version relies on shared memory more heavily, but about 29 percent of the wavefronts were flagged for excessive shared memory access. That didn’t happen in the earlier ones. The grid size also hasn’t changed, so it’s still launching a small number of blocks, which underutilizes the GPU.

3. Which bottlenecks, if any, were improved by this kernel?

    The biggest win here is how much cleaner the global memory access became. Reducing those uncoalesced accesses made a big
difference, and the memory chart shows that fewer threads are stepping on each other when trying to fetch data. The L2 cache hit rate also improved a little, which means we’re getting better reuse of data as well. Compute throughput went up, and even though execution time increased, the GPU is spending more time doing useful work. This version sets the stage for better performance if we can keep improving how we use shared memory and launch configuration.

# Part 4: Caching Halo Cells

1. Compared to the baseline and optimized kernels, what measureable performance improvements did you achieve with the tiled kernel? Give as much detail as possible (execution time, memory usage, etc.).

    Caching the halo cells slightly reduced the execution time to 8.35 microseconds, which is almost identical to the tiled
version without caching, so we didn't see much gain there. However, there was a noticeable bump in memory throughput, going from 34.58 GB/s in the tiled kernel to 51.39 GB/s in the cached version. That’s a good sign that memory transactions are being handled more efficiently. On top of that, compute throughput rose slightly to 8.90% and memory throughput hit 11.57%, which are both the highest values across all kernels tested. This shows that although runtime didn’t improve much, the hardware was used more effectively during execution.


2. What are the performance bottlenecks of the optimized kernel? Are any of them the same as the baseline kernel?

    Unfortunately, the same types of bottlenecks are still holding us back. We're still running into scoreboard stalls, with each
warp waiting 6.0 cycles on average, which is almost identical to the previous tiled kernel and not much better than the baseline. Bank conflicts in shared memory are still present too, and in this case, 44.87% of the shared loads ran into a 1.8-way conflict. That means the halo cells might not have been cached in the cleanest way possible. Warp issue slot utilization also isn’t perfect, sitting at 84.97%, so we're not scheduling instructions every cycle like we could be. These kinds of stalls and shared memory issues were already problems in the earlier versions and still haven’t been eliminated here.


3. Which bottlenecks, if any, were improved by this kernel?

    The most obvious improvement was in memory efficiency. The L2 cache hit rate was slightly better, and uncoalesced memory
accesses were reduced to 41%, which is an improvement over the baseline’s 67%. That means global memory is being accessed in a more organized way, and caching the halo cells definitely played a role in that. While we didn't completely get rid of shared memory bank conflicts, we likely avoided even worse contention by using the cache. So even if execution time didn’t drastically improve, this version is using memory more intelligently, which is a step in the right direction.



Note: Thank you to Maalik Meneimneh for letting me run this program on his GPU. For some reason I think the virtual GPU was either broken, or just didn't want me to run my program on it at all. Threfore, I just ran it on an actual GPU locally. 