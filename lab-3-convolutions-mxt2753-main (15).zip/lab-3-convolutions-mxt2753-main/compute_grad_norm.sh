#!/bin/bash
./build/release/grad_image img/gpgpu.png