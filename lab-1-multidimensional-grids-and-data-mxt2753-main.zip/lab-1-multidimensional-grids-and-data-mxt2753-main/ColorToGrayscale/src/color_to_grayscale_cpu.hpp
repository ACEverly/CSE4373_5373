#pragma once

void color_to_grayscale_cpu(unsigned char *output, unsigned char *input, unsigned int y,
                            unsigned int x);