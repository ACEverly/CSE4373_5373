#pragma once

void colorToGrayscale(float *output, float *input, int y, int x);