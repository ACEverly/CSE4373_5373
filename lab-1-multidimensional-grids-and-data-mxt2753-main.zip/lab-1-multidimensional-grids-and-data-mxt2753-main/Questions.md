# Part 1: Color to Grayscale

1. The kernel code is written in a way that each thread processes considers all 3 channels per pixel. How would this compare to a kernel that processes only one channel per pixel?

  A kernel processing one channel per pixel would require separate kernel launches for each channel, leading to increased memory transfers and reduced efficiency. The current approach, handling all three channels in one go, maximizes memory locality and reduces redundant operations, making it more optimal for GPU execution.


# Part 2: Blurring an Image

1. When checking for kernel size, does it make more sense to check this before launching the kernel or inside the kernel? Why?

  It is better to check the kernel size before launching the kernel. Doing it inside the kernel means every thread would have to perform the same conditional check, leading to wasted compute cycles. Checking beforehand avoids unnecessary GPU execution if the parameters are invalid, ensuring only meaningful work is assigned to the threads.


# Part 3: Matrix Multiplication

1. How many global memory access does each thread perform given two matrices of size $m \times n$ and $n \times p$, respectively?

  Each thread accesses one row from matrix A and one column from matrix B, leading to n reads from A and n reads from B. Since each thread writes one element to the output matrix, this results in 2n global mem. accesses per thread. Given threads, the total global memory accesses across all threads is 2mnp.

  
