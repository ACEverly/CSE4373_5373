#pragma once

void blur(float *out, float *in, int size, int width, int height, int channels);