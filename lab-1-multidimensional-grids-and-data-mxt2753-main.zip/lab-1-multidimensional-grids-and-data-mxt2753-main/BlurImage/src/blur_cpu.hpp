#pragma once

void blur_cpu(unsigned char *out, unsigned char *in, int size,
              unsigned int height, unsigned int width);