#!/bin/bash

ncu --set full -o matmul_benchmark -f ./build/release/matmul_benchmark 1024 1024 1024