# Matrix Multiplication

The following questions are based on profiling the provided matrix multiplication code using NSight.
(NOTE: not sure if you wanted me to go into very specific details like number so I'll jsut go into general terms)
1. Is this code compute bound or memory bound? How do you know?

  The code is memory-bound.
  Evidence from NSight Compute: The memory throughput is high (~97.38% of speed of light for tiled) and L2 cache throughput is also high, meaning the kernel is limited by memory bandwidth rather than raw     computational power.
  why/How do you know? Even though computation is significant, global memory accesses are the limiting factor, especially in naive matrix multiplication.

2. Using Nsight Compute, identify the biggest performance bottleneck in the code. What is the cause of this bottleneck?

  Biggest Bottleneck: Memory bandwidth utilization
  Evidence from NSight Compute:
  Naïve Kernel: Excessive global memory accesses (~60-90% L2 hit rate, but still frequent global reads).
  Tiled Kernel: Shared memory bank conflicts (~80% memory utilization but lower compute efficiency).
  Coarsened Kernel: Warp serialization & register pressure (~31.47 warps per scheduler, lower than optimal).

# Tiled Matrix Multiplication

3. What is different about the bounds of this kernel compared to the naive matrix multiplication kernel?

  The naïve kernel computes one output per thread directly from global memory, leading to many redundant global memory accesses.
  The tiled kernel uses shared memory, significantly reducing global memory traffic by a factor of TILE_WIDTH.

4. Using Nsight Compute, identify the biggest performance bottleneck in the tiled matrix multiplication kernel. What is the cause of this bottleneck?

Biggest Bottleneck: Shared memory bank conflicts
What is the Cause of this bottleneck : Multiple threads access the same memory bank, leading to serialization and stalls in memory operations.

# Coarsened Matrix Multiplication

5. How does this kernel compare to the tiled matrix multiplication kernel in terms of performance? What is the cause of this difference?
 
  The coarsened kernel is faster than the tiled kernel.
  The Reason/why?Each thread processes multiple elements, reducing thread launch overhead. Better memory coalescing, improving global memory bandwidth utilization.
  Performance Boost: ~5-15% improvement over tiled kernel (depending on matrix size).

6. Using Nsight Compute, what line of code is the biggest performance bottleneck in the coarsened matrix multiplication kernel? What is the cause of this bottleneck?
  Biggest Bottleneck: High register usage + warp serialization.
This is because: The register pressure is high, reducing warp occupancy (~31.47 warps per scheduler). Warp serialization occurs when dependent instructions stall execution, limiting performance


