#include "gputk.h"
#include "reduce.h"

int main(int argc, char **argv) {
    int ii;
    gpuTKArg_t args;
    float *hostInput;  // The input 1D list
    float *hostOutput; // The output list
    float *deviceInput;
    float *deviceOutput;
    int numInputElements;  // number of elements in the input list
    int numOutputElements; // number of elements in the output list

    args = gpuTKArg_read(argc, argv);

    hostInput =
        (float *)gpuTKImport(gpuTKArg_getInputFile(args, 0), &numInputElements);

    numOutputElements = numInputElements / (BLOCK_SIZE << 1);
    if (numInputElements % (BLOCK_SIZE << 1)) {
        numOutputElements++;
    }
    hostOutput = (float *)malloc(numOutputElements * sizeof(float));

    //reduce(hostInput, hostOutput, numInputElements);

    //@@ Allocate GPU memory here
    cudaMalloc((void **)&deviceInput, numInputElements * sizeof(float));
    cudaMalloc((void **)&deviceOutput, numOutputElements * sizeof(float));

    //@@ Copy memory to the GPU here
    cudaMemcpy(deviceInput, hostInput, numInputElements * sizeof(float), cudaMemcpyHostToDevice);

    //@@ Initialize the grid and block dimensions here
    dim3 DimGrid(numOutputElements, 1, 1);
    dim3 DimBlock(BLOCK_SIZE, 1, 1);

    //@@ Launch the GPU Kernel here
   // reduce<<<dimGrid, dimBlock>>>(deviceInput, deviceOutput, numInputElements);
     reduce(deviceInput, deviceOutput, numInputElements); 

    //@@ Copy the GPU memory back to the CPU here
    cudaMemcpy(hostOutput, deviceOutput, numOutputElements * sizeof(float), cudaMemcpyDeviceToHost);

    /********************************************************************
     * Reduce output vector on the host
     ********************************************************************/

    //@@ Free the GPU memory here
    for (int i = 1; i < numOutputElements; i++) {
        hostOutput[0] += hostOutput[i];
    }
    
    std::cout << "numOutputElements: " << numOutputElements << std::endl;
    std::cout << std::setprecision(2) << std::fixed;
    std::cout << "The sum of the input list is: " << hostOutput[0] << std::endl;

    gpuTKSolution(args, hostOutput, 1);

    //@@ Free the GPU memory here

    free(hostInput);
    free(hostOutput);

    return 0;
}
