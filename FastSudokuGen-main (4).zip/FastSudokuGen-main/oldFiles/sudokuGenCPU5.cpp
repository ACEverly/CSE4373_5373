#include <stdio.h>
#include <stdlib.h> 
#include <time.h>

#define MAXCHARS 100
#define CHANCE_REMOVE 2

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum);

int* initializeSudokuPuzzle(int puzzleSize);
void finalizePuzzle(int puzzleSize, int* sudokuPuzzle);
void printSudokuPuzzle(int puzzleSize, int* sudokuPuzzle);
void saveSudokuPuzzle(int puzzleSize, int* sudokuPuzzle, int puzzleID);


bool fill_board(int puzzleBoxSize, int* board, int row = 0, int col = 0);
bool sudokuValueGood (int x, int y, int value, int puzzleBoxSize, int puzzleSize, int* sudokuPuzzle);
bool checkSudokuPuzzle(int puzzleSize, int* sudokuPuzzle);

bool is_valid(int* board, int puzzleSize, int boxSize, int row, int col, int num); 

int main(int argc, char** argv)
{
    sudokuGenCPU(3, 3);
    return 0;
}

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum)
{
    srand(time(0));
    int puzzleSize = puzzleBoxSize * puzzleBoxSize;

    for (int p = 0; p < puzzleNum; p++)
    {
        
        int* sudokuPuzzle = initializeSudokuPuzzle(puzzleSize);
        printSudokuPuzzle(puzzleSize, sudokuPuzzle);
        
        bool goodGenerate = fill_board(puzzleBoxSize, sudokuPuzzle);
        printSudokuPuzzle(puzzleSize, sudokuPuzzle);

        if (goodGenerate == true)
        {
            finalizePuzzle(puzzleSize, sudokuPuzzle);
            printSudokuPuzzle(puzzleSize, sudokuPuzzle);
            saveSudokuPuzzle(puzzleSize, sudokuPuzzle, p);
        }
        
        else
        {
            printf("\nBad generate at puzzle number %d\n", p);
        }
        
        
        free(sudokuPuzzle);
    }

    return;
}

//new CPU functions

void saveSudokuPuzzle(int puzzleSize, int* sudokuPuzzle, int puzzleID)
{
    char sudokuFilenName[1000];
    sprintf(sudokuFilenName, "puzzles/puzzle%d.sudoku", puzzleID);
    
    FILE * sudokuFile = fopen(sudokuFilenName, "w+");
    fprintf(sudokuFile, "\nSudoku File Number %d\n", puzzleID);
    
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            int curValue = sudokuPuzzle[x * puzzleSize + y];
            if (curValue == -1)
            {
                fprintf(sudokuFile, "   X");
            }
            else
            {
                fprintf(sudokuFile, "%3d", curValue);
            }
        }
        printf("\n");
    }
    
    fclose(sudokuFile);
    return;
}

void finalizePuzzle(int puzzleSize, int* sudokuPuzzle)
{
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            int removeValue = rand() % CHANCE_REMOVE;
            if (removeValue == 1)
            {
                sudokuPuzzle[x * puzzleSize + y] = -1;
            }  
        }
    }
}

bool fill_board(int puzzleBoxSize, int* board, int row, int col)
{
    int puzzleSize = puzzleBoxSize * puzzleBoxSize;

    if (row == puzzleSize)
    {
        return true;
    }

    if (col == puzzleSize)
    {
        return fill_board(puzzleSize, board, row + 1, 0);
    }

    int nums[puzzleSize];
    for (int i = 0; i < puzzleSize; i++)
    {
        nums[i] = i + 1;
    }

    for (int i = puzzleSize - 1; i > 0; i--)
    {
        int j = rand() % (i + 1);
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    for (int i = 0; i < puzzleBoxSize; i++)
    {
        int num = nums[i];
        if (sudokuValueGood(row, col, num, puzzleBoxSize, puzzleSize, board))
        {
            board[row * puzzleSize + col] == num;
            if (fill_board(puzzleBoxSize, board, row, col + 1))
            {
                return true;
            }
            //board[row * puzzleSize + col] = 0;
        }
    }
    return false;
}

int* initializeSudokuPuzzle(int puzzleSize)
{
    int* sudokuPuzzle = (int*)malloc(puzzleSize * puzzleSize * sizeof(int));
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            sudokuPuzzle[x * puzzleSize + y] = -1;
        }
    }

    return sudokuPuzzle;
}

void printSudokuPuzzle(int puzzleSize, int* sudokuPuzzle)
{
    printf("\n\n");
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            int curValue = sudokuPuzzle[x * puzzleSize + y];
            if (curValue == -1)
            {
                printf("   X");
            }
            else
            {
                printf("3%d", curValue);
            }
        }
        printf("\n");
    }
    return;
}

bool sudokuValueGood (int x, int y, int value, int puzzleBoxSize, int puzzleSize, int* sudokuPuzzle)
{
    bool alreadyFilled = false;
    bool sameInRow = false;
    bool sameInCol = false;
    bool sameInBox = false;
    
    if (sudokuPuzzle[x * puzzleSize + y] != -1)
    {
        alreadyFilled = true;
    }
    
    if (alreadyFilled == false)
    {
        for (int i = 0; (i < puzzleSize) && (sameInRow == false); i++)
        {
            if (sudokuPuzzle[i * puzzleSize + y] == value)
            {
                sameInRow = true;
            }                
        }
    }

    if (sameInRow == false)
    {
        for (int j = 0; (j < puzzleSize) && (sameInCol == false); j++)
        {
            if (sudokuPuzzle[x * puzzleSize + j] == value)
            {
                sameInCol = true;
            }
        }
    }

    if ((sameInRow == false) && (sameInCol == false))
    {
        int box_start_x = x;
        while (box_start_x % puzzleBoxSize != 0)
        {
            box_start_x--;
        }
        int box_end_x = box_start_x + puzzleBoxSize - 1;

        int box_start_y = y;
        while (box_start_y % puzzleBoxSize != 0)
        {
            box_start_y--;
        }
        int box_end_y = box_start_y + puzzleBoxSize - 1;

        
        int k = box_start_x;
        int l = box_start_y;

        while ((sameInBox == false) && (k <= box_end_x))
        {
            while ((l <= box_end_y) && (sameInBox == false))
            {
                if (sudokuPuzzle[k * puzzleSize + l] == value)
                {
                    sameInBox = true;
                }
                l++;
            }
            l = box_start_y;
            k++;
        }

    }

    if ((alreadyFilled == false) && (sameInRow == false) && (sameInCol == false) && (sameInBox == false))
    {
        return true;
    }

    else
    {
        return false;
    }
}

bool is_valid(int* board, int puzzleSize, int boxSize, int row, int col, int num) {
    //  x < N; x++
for (int x = 0; x < puzzleSize; x++) {
if (board[row * puzzleSize + x] == num || board[x * puzzleSize + col] == num)
return false;
}

//int startRow = row - row % 3, startCol = col - col % 3;
int startRow = row - row % boxSize; 
int startCol = col - col % boxSize;
for (int i = 0; i < boxSize; i++)
for (int j = 0; j < boxSize; j++)
if (board[(startRow + i) * puzzleSize + (startCol + j)] == num)
    return false;

return true;
}

bool checkSudokuPuzzle(int puzzleSize, int* sudokuPuzzle)
{
    bool puzzleSolved = true;

    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            if (sudokuPuzzle[x * puzzleSize + y] == -1)
            {
                puzzleSolved = false;
            }
        }
    }

    return puzzleSolved;
}