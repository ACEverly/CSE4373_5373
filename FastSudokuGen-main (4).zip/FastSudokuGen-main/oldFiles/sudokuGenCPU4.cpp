#include <stdlib.h>
#include <stdio.h>
#include <time.h>

//#define maalik malloc
#define MIN_REPLACEMENTS 3
#define MAX_ATTEMPTS 10

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum);
void printSudokuPuzzle(int puzzleSize, int* sudokuPuzzle);
void initializeSudokuPuzzle(int puzzleSize, int* sudokuPuzzle);
bool sudokuValueGood (int x, int y, int value, int puzzleBoxSize, int puzzleSize, int* sudokuPuzzle);
bool checkSudokuPuzzle(int puzzleSize, int* sudokuPuzzle);

int main (int argc, char** argv)
{
    sudokuGenCPU(3, 1);
    return 0;
}

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum)
{
    srand(time(0));
    int puzzleSize = puzzleBoxSize * puzzleBoxSize;
    int* sudokuPuzzle = (int*)malloc(puzzleSize * puzzleSize * sizeof(int));

    initializeSudokuPuzzle(puzzleSize, sudokuPuzzle);
    // erase this line VVV?
    //printSudokuPuzzle(puzzleSize, sudokuPuzzle);
    //

    bool puzzleSolved = false;
    int attempts = 0;
    while (puzzleSolved == false) 
    {
        while ((puzzleSolved == false) && (attempts < MAX_ATTEMPTS))
        {
            for (int value = 1; value < puzzleSize + 1; value++)
            {
                // add theses lie
                // int maxReplacements = puzzleBoxSize; 
                // int minReplacements = MIN_REPLACEMENTS;
                //if (minReplacements > maxReplacements) minReplacements = maxReplacements;
                int replacements = rand() % (puzzleBoxSize - MIN_REPLACEMENTS + 1) + MIN_REPLACEMENTS; //replace this with this VV
                ///                       % (maxReplacements - minReplacements + 1) + minReplacements;

                for (int r = 0; r < replacements; r++)
                {
                    int x = rand() % puzzleSize;
                    int y = rand() % puzzleSize;

                    bool valueGood = sudokuValueGood(x, y, value, puzzleBoxSize, puzzleSize, sudokuPuzzle);
                    // erase this^^^ 

                    if (valueGood == true) //maybe this: if(sudokuValueGood(x,y, value, puzzleBoxSize, puzzleSize, sudokuPuzzle))

                    {
                        attempts = 0;
                        sudokuPuzzle[x * puzzleSize + y] = value;
                    }
                }
            }



            puzzleSolved = checkSudokuPuzzle(puzzleSize, sudokuPuzzle);
            // Erase this line VVV?
            printSudokuPuzzle(puzzleSize, sudokuPuzzle);

            attempts++;

            if ((attempts == MAX_ATTEMPTS) && (puzzleSolved == false))
            {
                printf("\nAttempts timed out; restarting puzzle\n");
                attempts = 0;
                initializeSudokuPuzzle(puzzleSize, sudokuPuzzle);
            }
        }
    }

    printSudokuPuzzle(puzzleSize, sudokuPuzzle);
    free(sudokuPuzzle);
    return;
}

void initializeSudokuPuzzle(int puzzleSize, int* sudokuPuzzle)
{
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            sudokuPuzzle[x * puzzleSize + y] = -1;
        }
    }
}

void printSudokuPuzzle(int puzzleSize, int* sudokuPuzzle)
{
    printf("\n\n");
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            printf(" %d", sudokuPuzzle[x * puzzleSize + y]);
        }
        printf("\n");
    }
    return;
}

bool sudokuValueGood (int x, int y, int value, int puzzleBoxSize, int puzzleSize, int* sudokuPuzzle)
{
    bool alreadyFilled = false;
    bool sameInRow = false;
    bool sameInCol = false;
    bool sameInBox = false;
    
    if (sudokuPuzzle[x * puzzleSize + y] != -1)
    {
        alreadyFilled = true;
    }
    
    if (alreadyFilled == false)
    {
        for (int i = 0; (i < puzzleSize) && (sameInRow == false); i++)
        {
            if (sudokuPuzzle[i * puzzleSize + y] == value)
            {
                sameInRow = true;
            }                
        }
    }

    if (sameInRow == false)
    {
        for (int j = 0; (j < puzzleSize) && (sameInCol == false); j++)
        {
            if (sudokuPuzzle[x * puzzleSize + j] == value)
            {
                sameInCol = true;
            }
        }
    }

    if ((sameInRow == false) && (sameInCol == false))
    {
        int box_start_x = x;
        while (box_start_x % puzzleBoxSize != 0)
        {
            box_start_x--;
        }
        int box_end_x = box_start_x + puzzleBoxSize - 1;

        int box_start_y = y;
        while (box_start_y % puzzleBoxSize != 0)
        {
            box_start_y--;
        }
        int box_end_y = box_start_y + puzzleBoxSize - 1;

        
        int k = box_start_x;
        int l = box_start_y;

        while ((sameInBox == false) && (k <= box_end_x))
        {
            while ((l <= box_end_y) && (sameInBox == false))
            {
                if (sudokuPuzzle[k * puzzleSize + l] == value)
                {
                    sameInBox = true;
                }
                l++;
            }
            l = box_start_y;
            k++;
        }

    }

    if ((alreadyFilled == false) && (sameInRow == false) && (sameInCol == false) && (sameInBox == false))
    {
        return true;
    }

    else
    {
        return false;
    }
}

bool checkSudokuPuzzle(int puzzleSize, int* sudokuPuzzle)
{
    bool puzzleSolved = true;

    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            if (sudokuPuzzle[x * puzzleSize + y] == -1)
            {
                puzzleSolved = false;
            }
        }
    }

    return puzzleSolved;
}