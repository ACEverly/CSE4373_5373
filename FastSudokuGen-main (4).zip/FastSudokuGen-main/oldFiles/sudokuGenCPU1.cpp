#include <stdlib.h>
#include <stdio.h>
#include <time.h>

void SudokuGenCPU(int puzzleBoxSize, int puzzleNum);

int main(int argc, char** argv)
{
    SudokuGenCPU(3, 1);
    return 0;
}

void SudokuGenCPU(int puzzleBoxSize, int puzzleNum)
{   
    srand(time(0));
    int puzzleHeight = puzzleBoxSize * puzzleBoxSize;
    int puzzleWidth = puzzleBoxSize * puzzleBoxSize;

    int SudokuPuzzle[puzzleWidth][puzzleHeight];
        
    for (int x = 0; x < puzzleWidth; x++)
    {
        for (int y = 0; y < puzzleHeight; y++)
        {
            SudokuPuzzle[x][y] = -1;
        }
    }

    int superAttempts = 0;
    for (int x = 0; x < puzzleWidth; x++)
    {
        for (int y = 0; y < puzzleHeight; y++)
        { 
            if (superAttempts > 50)
            {
                x = 0;
                y = 0;
                superAttempts = 0;

                printf("\nReset\n");

                for (int x = 0; x < puzzleWidth; x++)
                {
                    for (int y = 0; y < puzzleHeight; y++)
                    {
                        SudokuPuzzle[x][y] = -1;
                    }
                }
            }
            
            int proposedValue = -1;
            bool foundGoodValue = false;
            int attempts = 0;

            printf("\n\n");
            for (int x = 0; x < puzzleWidth; x++)
            {
                for (int y = 0; y < puzzleHeight; y++)
                {
                    printf(" %d", SudokuPuzzle[x][y]);
                }
                printf("\n");
            }

            while (foundGoodValue == false)
            {
                if (attempts == 10)
                {
                    attempts = 0;
                    if ((x != 0) && (y != 0))
                    {
                        if (y == 0)
                        {
                            x--;
                            y = puzzleWidth - 1;
                        }
                        else
                        {
                            y--;
                        }
                    }                                    
                }
                          
                superAttempts++;
                attempts++;
                bool sameInRow = false;
                bool sameInCol = false;
                bool sameInBox = false;
                
                proposedValue = rand() % ((puzzleBoxSize * puzzleBoxSize) + 1 - 1) + 1;

                int i = 0;
                while ((i < puzzleWidth) && (sameInRow == false))
                {
                    if (SudokuPuzzle[i][y] == proposedValue)
                    {
                        sameInRow = true;
                    }
                    i++;                   
                }

                if (sameInRow == false)
                {
                    int j = 0;
                    while ((j < puzzleHeight) && (sameInCol == false))
                    {
                        if (SudokuPuzzle[x][j] == proposedValue)
                        {
                            sameInCol = true;
                        }
                        j++;
                    }
                }

                if ((sameInRow == false) && (sameInCol == false))
                {
                    int box_start_x = x;
                    while (box_start_x % puzzleBoxSize != 0)
                    {
                        box_start_x--;
                    }
                    int box_end_x = box_start_x + puzzleBoxSize - 1;

                    int box_start_y = y;
                    while (box_start_y % puzzleBoxSize != 0)
                    {
                        box_start_y--;
                    }
                    int box_end_y = box_start_y + puzzleBoxSize - 1;

                    
                    int k = box_start_x;
                    int l = box_start_y;

                    while ((sameInBox == false) && (k < box_end_x))
                    {
                        while ((l < box_end_y) && (sameInBox == false))
                        {
                            if (SudokuPuzzle[k][l] == proposedValue)
                            {
                                sameInBox = true;
                            }
                            l++;
                        }
                        l = box_start_y;
                        k++;
                    }

                }

                if ((sameInRow == false) && (sameInCol == false) && (sameInBox == false))
                {
                    
                    foundGoodValue = true;
                    SudokuPuzzle[x][y] = proposedValue;
                    attempts = 0;
                    superAttempts = 0;
                }
            }
        }
    }

    printf("\n\n");
    for (int x = 0; x < puzzleWidth; x++)
    {
        for (int y = 0; y < puzzleHeight; y++)
        {
            printf(" %d", SudokuPuzzle[x][y]);
        }
        printf("\n");
    }

    return;
}