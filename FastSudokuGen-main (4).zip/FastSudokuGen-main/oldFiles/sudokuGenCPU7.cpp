// #include "gputk.h"

#include <stdio.h>
#include <stdlib.h> // for malloc and free just in case
#include <time.h>

// This constant should match the number of Sudoku boards we want to generate
#define TOTAL_BOARDS 1024
#define N 9

// Device function to check if placing a number is valid at board[row][col]
bool is_valid(int board[N][N], int row, int col, int num) {
    for (int x = 0; x < N; x++) {
        if (board[row][x] == num || board[x][col] == num)
            return false;
    }

    int startRow = row - row % 3, startCol = col - col % 3;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i + startRow][j + startCol] == num)
                return false;

    return true;
}

// Device recursive function to fill the board using backtracking
bool fill_board(int board[N][N], int row = 0, int col = 0) {
    if (row == N)
        return true;
    if (col == N)
        return fill_board(board, row + 1, 0);

    int nums[N];
    for (int i = 0; i < N; i++) nums[i] = i + 1;

    // Fisher-Yates shuffle to randomize the number order
    for (int i = N - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    for (int i = 0; i < N; i++) {
        int num = nums[i];
        if (is_valid(board, row, col, num)) {
            board[row][col] = num;
            if (fill_board(board, row, col + 1))
                return true;
            board[row][col] = 0;
        }
    }
    return false;
}

// Kernel to generate Sudoku boards
void generate_sudoku_boards(int *output) {
    int board[N][N] = {0};

    // Fill the board
    if (!fill_board(board)) return;

    // Copy board to output
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
    // i thbik this the problem
            output[i * N + j] = board[i][j];
}

int main(){
    
    int totalBoards= TOTAL_BOARDS;
    int boardSize = N * N;
    size_t memSize = totalBoards * boardSize * sizeof(int); 

    //all device mem
    int * output = (int*)malloc(memSize);
    //cudaMalloc(&d_output, memSize);

    generate_sudoku_boards(output);

    //print out some boards
    for(int b= 0; b<3; b++){
        printf("\n generated Sudoku Board #%d: \n", b);
        for(int i = 0; i < N; i++){
            for (int j = 0; j < N; j++){
                printf("%2d", output[b* boardSize + i * N + j]);
            }
            printf("\n");
        }
    }

    free(output);

    return 0; 

}