#include <stdlib.h>
#include <stdio.h>
#include <time.h>

//#define malloc malloc

#define MIN_REPLACEMENTS 3

//shoduldn't you do something like this instead of this^^^
//void printSudokuPuzzle(int** sudokuPuzzle, int puzzleWidth);
//void initializeSudokuPuzzle(int** sudokuPuzzle, int puzzleWidth);
//bool checkSudokuPuzzle(int** sudokuPuzzle, int puzzleWidth);
//bool sudokuValueGood(int x, int y, int value, int** sudokuPuzzle, int puzzleWidth);

// void sudokuGenCPU(int puzzleBoxSize, int puzzleNum);
// void initializeSudokuPuzzle(int* sudokuPuzzle[]);
// void printSudokuPuzzle(int* sudokuPuzzle[]);
// bool checkSudokuPuzzle(int* sudokuPuzzle[]);
// bool sudokuValueGood(int x, int y, int value, int* sudokuPuzzle[]);

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum);
void printSudokuPuzzle(int puzzleWidth, int puzzleHeight, int* sudokuPuzzle[]);
void initializeSudokuPuzzle(int puzzleWidth, int puzzleHeight, int* sudokuPuzzle[]);
bool checkSudokuPuzzle(int puzzleWidth, int puzzleHeight, int* sudokuPuzzle[]);
bool sudokuValueGood(int x, int y, int value, int puzzleWidth, int puzzleHeight, int* sudokuPuzzle[]);
//SUGGESTION: instead of calling like initializeSudokuPuzzle(puzzleWidth, puzzleHeight, sudokuPuzzle[puzzleWidth][puzzleHeight]);
// correct calling: initializeSudokuPuzzle(puzzleWidth, puzzleHeight, sudokuPuzzle);
// printSudokuPuzzle(puzzleWidth, puzzleHeight, sudokuPuzzle);
//try this for funct declare: 
//void initializeSudokuPuzzle(int puzzleWidth, int puzzleHeight, int sudokuPuzzle[][puzzleHeight]);
//void printSudokuPuzzle(int puzzleWidth, int puzzleHeight, int sudokuPuzzle[][puzzleHeight]);



int main(int argc, char** argv)
{
    sudokuGenCPU(3, 1);
    return 0;
}

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum)
{   
    srand(time(0));
    int puzzleWidth = puzzleBoxSize * puzzleBoxSize;
    int puzzleHeight = puzzleBoxSize * puzzleBoxSize;

    int sudokuPuzzle[puzzleWidth][puzzleHeight];

    // int** sudokuPuzzle = (int**)malloc(puzzleWidth * sizeof(int*));
    // for (int i = 0; i < puzzleWidth; i++)
    // {
    //     sudokuPuzzle[i] = (int*)malloc(puzzleHeight * sizeof(int));
    // SUGGESTION: free(sudokuPuzzle[i]);
    // }
    //SUGGESTION: free(sudokuPuzzle);
    ///FREE IT???^
    
    initializeSudokuPuzzle(puzzleWidth, puzzleHeight, sudokuPuzzle[puzzleWidth][puzzleHeight]);
    printSudokuPuzzle(puzzleWidth, puzzleHeight, sudokuPuzzle[puzzleWidth][puzzleHeight]);
        
    bool puzzleSolved = false;
    // shouldn't you add max attempts limit for puzzleSolved == false? 
    //int attempts = 0;while (!puzzleSolved && attempts < 10000) { ...
    //attempts .. }
    //if(attempts >= 10000){ printf("failed to generate puzzle after 10000 tries.")}
    //Potential problem: random used too much?
    int value = 0;
    while (puzzleSolved == false)
    {
        for (int value = 1; value < puzzleBoxSize + 1; value++)
        {
            int replacements = rand() % (puzzleBoxSize - MIN_REPLACEMENTS + 1) + MIN_REPLACEMENTS;
            // SUGGESTION DO TWO LINES LIKE THIS??:
            // int max_replacements = puzzleBoxSize;
            // if (MIN_REPLACEMENTS > puzzleBoxSize) MIN_REPLACEMENTS = puzzleBoxSize;
            for (int r = 0; r < replacements; r++)
            {
                int x = rand() % puzzleWidth;
                int y = rand() % puzzleHeight;

                //printf("\n%d %d", x, y);

                if (sudokuValueGood(x, y, value, puzzleWidth, puzzleHeight, sudokuPuzzle[puzzleWidth][puzzleHeight]) == true)
                {
                    sudokuPuzzle[x][y] = value;
                }
            }
        }
        puzzleSolved = checkSudokuPuzzle(puzzleWidth, puzzleHeight, sudokuPuzzle[puzzleWidth][puzzleHeight]);
        printSudokuPuzzle(puzzleWidth, puzzleHeight, sudokuPuzzle[puzzleWidth][puzzleHeight]);
    }

    //printSudokuPuzzle(sudokuPuzzle);
    return;
}

void printSudokuPuzzle(int puzzleWidth, int puzzleHeight, int* sudokuPuzzle[])
{
    printf("\n\n");
    for (int x = 0; x < puzzleWidth; x++)
    {
        for (int y = 0; y < puzzleHeight; y++)
        {
            printf(" %d", sudokuPuzzle[x][y]);
        }
        printf("\n");
    }
    return;
}

bool checkSudokuPuzzle(int puzzleWidth, int puzzleHeight, int sudokuPuzzle[puzzleWidth][puzzleHeight])
{
    int puzzleBoxSize = sizeof(*sudokuPuzzle)/sizeof(int*);
    int puzzleHeight = puzzleBoxSize * puzzleBoxSize;
    int puzzleWidth = puzzleBoxSize * puzzleBoxSize;

    bool puzzleSolved = true;

    for (int x = 0; x < puzzleWidth; x++)
    {
        for (int y = 0; y < puzzleWidth; y++)
        {
            if (sudokuPuzzle[x][y] == -1)
            {
                puzzleSolved = false;
            }
        }
    }

    return puzzleSolved;
}

void initializeSudokuPuzzle(int puzzleWidth, int puzzleHeight, int sudokuPuzzle[puzzleWidth][puzzleHeight])
{
    int puzzleBoxSize = sizeof(*sudokuPuzzle)/sizeof(int*);
    int puzzleHeight = puzzleBoxSize * puzzleBoxSize;
    int puzzleWidth = puzzleBoxSize * puzzleBoxSize;

    for (int x = 0; x < puzzleWidth; x++)
    {
        for (int y = 0; y < puzzleHeight; y++)
        {
            sudokuPuzzle[x][y] = -1;
        }
    }
    return;
}

bool sudokuValueGood(int x, int y, int value, int puzzleWidth, int puzzleHeight, int sudokuPuzzle[puzzleWidth][puzzleHeight]) 
{
    bool alreadyFilled = false;
    bool sameInRow = false;
    bool sameInCol = false;
    bool sameInBox = false;

    int puzzleBoxSize = sizeof(*sudokuPuzzle)/sizeof(int*);
    int puzzleHeight = puzzleBoxSize * puzzleBoxSize;
    int puzzleWidth = puzzleBoxSize * puzzleBoxSize;

    if (sudokuPuzzle[x][y] != -1)
    {
        alreadyFilled = true;
    }
    
    if (alreadyFilled == false)
    {
        for (int i = 0; (i < puzzleWidth) && (sameInRow == false); i++)
        {
            if (sudokuPuzzle[i][y] == value)
            {
                sameInRow = true;
            }                
        }
    }

    if (sameInRow == false)
    {
        for (int j = 0; (j < puzzleHeight) && (sameInCol == false); j++)
        {
            if (sudokuPuzzle[x][j] == value)
            {
                sameInCol = true;
            }
        }
    }

    if ((sameInRow == false) && (sameInCol == false))
    {
        int box_start_x = x;
        while (box_start_x % puzzleBoxSize != 0)
        {
            box_start_x--;
        }
        int box_end_x = box_start_x + puzzleBoxSize - 1;

        int box_start_y = y;
        while (box_start_y % puzzleBoxSize != 0)
        {
            box_start_y--;
        }
        int box_end_y = box_start_y + puzzleBoxSize - 1;

        
        int k = box_start_x;
        int l = box_start_y;

        while ((sameInBox == false) && (k <= box_end_x))
        //while ((sameInBox == false) && (k <= box_end_x))
        {
            while ((l <= box_end_y) && (sameInBox == false))
            {
                if (sudokuPuzzle[k][l] == value)
                {
                    sameInBox = true;
                }
                l++;
            }
            l = box_start_y;
            k++;
        }

    }

    if ((alreadyFilled == false) && (sameInRow == false) && (sameInCol == false) && (sameInBox == false))
    {
        return true;
    }

    else
    {
        return false;
    }
}