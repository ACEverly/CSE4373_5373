mkdir puzzles
mkdir build

nvcc -rdc=true -o build/FastSudokuGen.o FastSudokuGen.cpp sudokuGenCUDA.cu sudokuGenCPU.cpp
nvcc -rdc=true -o build/benchmarkCUDA.o benchmarkCUDA.cpp sudokuGenCUDA.cu sudokuGenCPU.cpp
./build/FastSudokuGen.o