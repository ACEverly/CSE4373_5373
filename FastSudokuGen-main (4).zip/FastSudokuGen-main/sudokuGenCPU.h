#ifndef SUDOKUGENCPU_H
#define SUDOKUGENCPU_H

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum);
#endif