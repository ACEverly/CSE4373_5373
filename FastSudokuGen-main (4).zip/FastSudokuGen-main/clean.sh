rm -rf build
rm -rf puzzles
rm *.ncu-rep