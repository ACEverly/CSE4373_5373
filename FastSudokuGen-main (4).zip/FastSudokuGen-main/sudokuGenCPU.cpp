// #include "gputk.h"

#include <stdio.h>
#include <stdlib.h> // for malloc and free just in case
#include <time.h>

#include "sudokuGenCPU.h"

// This constant should match the number of Sudoku boards we want to generate
// #define TOTAL_BOARDS 1024
// #define N 9

#define MAXCHARS 1000
#define CHANCE_REMOVE 3
#define BLANK_VALUE -1
#define BLANK_CHAR 'X'

// Device function to check if placing a number is valid at board[row][col]
bool is_valid(int* board, int boxSize, int row, int col, int num) {
    int boardSize = boxSize * boxSize;
    for (int x = 0; x < boardSize; x++) {
        if (board[row * boardSize + x] == num || board[x * boardSize + col] == num)
            return false;
    }

    int startRow = row - row % boxSize, startCol = col - col % boxSize;
    for (int i = 0; i < boxSize; i++)
        for (int j = 0; j < boxSize; j++)
            if (board[((i + startRow) * boardSize) + (j + startCol)] == num)
                return false;

    return true;
}

// Device recursive function to fill the board using backtracking
bool fill_board(int* board, int boxSize, int row = 0, int col = 0) {
    int boardSize = boxSize * boxSize;
    if (row == boardSize)
        return true;
    if (col == boardSize)
        return fill_board(board, boxSize, row + 1, 0);

    int nums[boardSize];
    for (int i = 0; i < boardSize; i++) 
        nums[i] = i + 1;

    // Fisher-Yates shuffle to randomize the number order
    for (int i = boardSize - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    for (int i = 0; i < boardSize; i++) {
        int num = nums[i];
        if (is_valid(board, boxSize, row, col, num)) {
            board[row * boardSize + col] = num;
            if (fill_board(board, boxSize, row, col + 1))
                return true;
            board[row * boardSize + col] = BLANK_VALUE;
        }
    }
    return false;
}

int* initializeSudokuPuzzle(int puzzleSize)
{
    int* sudokuPuzzle = (int*)malloc(puzzleSize * puzzleSize * sizeof(int));
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            sudokuPuzzle[x * puzzleSize + y] = BLANK_VALUE;
        }
    }

    return sudokuPuzzle;
}

void printSudokuPuzzle(int puzzleSize, int* sudokuPuzzle)
{
    //printf("\n\n");
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            int curValue = sudokuPuzzle[x * puzzleSize + y];
            if (curValue == BLANK_VALUE)
            {
                printf("%3c", BLANK_CHAR);
            }
            else
            {
                printf("%3d", curValue);
            }
        }
        printf("\n");
    }

    printf("\n");
    return;
}

void saveSudokuPuzzle(int puzzleSize, int* sudokuPuzzle, int puzzleID)
{
    char sudokuFilenName[MAXCHARS];
    sprintf(sudokuFilenName, "puzzles/puzzle%d.sudoku", puzzleID);
    
    FILE * sudokuFile = fopen(sudokuFilenName, "w+");
    fprintf(sudokuFile, "\n\nSudoku File Number %d\n\n", puzzleID);
    
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            int curValue = sudokuPuzzle[x * puzzleSize + y];
            if (curValue == BLANK_VALUE)
            {
                fprintf(sudokuFile, "%3c", BLANK_CHAR);
            }
            else
            {
                fprintf(sudokuFile, "%3d", curValue);
            }
        }
        fprintf(sudokuFile, "\n");
    }
    
    fclose(sudokuFile);
    return;
}

void finalizePuzzle(int puzzleSize, int* sudokuPuzzle)
{
    for (int x = 0; x < puzzleSize; x++)
    {
        for (int y = 0; y < puzzleSize; y++)
        {
            int removeValue = rand() % CHANCE_REMOVE;
            if (removeValue == 1)
            {
                sudokuPuzzle[x * puzzleSize + y] = BLANK_VALUE;
            }  
        }
    }
}

void sudokuGenCPU(int puzzleBoxSize, int puzzleNum)
{
    srand(time(0));
    int puzzleSize = puzzleBoxSize * puzzleBoxSize;

    for (int p = 0; p < puzzleNum; p++)
    {
        
        int* sudokuPuzzle = initializeSudokuPuzzle(puzzleSize);
        //printSudokuPuzzle(puzzleSize, sudokuPuzzle);
        
        bool goodGenerate = fill_board(sudokuPuzzle, puzzleBoxSize);
        //printSudokuPuzzle(puzzleSize, sudokuPuzzle);

        if (goodGenerate == true)
        {
            finalizePuzzle(puzzleSize, sudokuPuzzle);
            printSudokuPuzzle(puzzleSize, sudokuPuzzle);
            saveSudokuPuzzle(puzzleSize, sudokuPuzzle, p);
        }
        
        else
        {
            printf("\nBad generate at puzzle number %d\n", p);
        }
        
        
        free(sudokuPuzzle);
    }

    return;
}

// int main(int argc, char** argv)
// {
//     sudokuGenCPU(4, 5);
//     return 0;
// }
