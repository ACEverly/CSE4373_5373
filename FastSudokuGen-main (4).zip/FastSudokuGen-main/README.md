# FastSudokuGen
## CUDA Accelerated Sudoku Puzzle Generator for CSE-4373 Semester Project
## Version 0.1

By: Mary-Rose Tracy, Maalik Meneimneh, Justin Barret

To compile and run this project, navigate a bash terminal to the FastSudokuGen kernel and run command: bash build_and_run.sh

To clean, run command: bash clean.sh

To run benchmark, run command: benchmarkCUDA.sh

Note 1: We we planning to implement a version of the CUDA enabled Sudoku generator where multiple threads work on one puzzle, but we have not done this yet.

Note 2: Included slideshow presentation uses an image from https://www.websudoku.com/