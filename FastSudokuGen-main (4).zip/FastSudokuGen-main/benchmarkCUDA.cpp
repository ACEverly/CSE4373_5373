#include <stdio.h>
// #include <stdlib.h>

#include "sudokuGenCUDA.h"

int main(int argc, char* argv[])
{
    printf("\nBenchmarking sudokuGenCUDA\n");
    sudokuGenCUDA(100, 5);
    return 0;
}