#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sudokuGenCPU.h"
#include "sudokuGenCUDA.h"

#define MAX_BOX_SIZE 6  

int main(int argc, char** argv)
{
    constexpr int STR_MAX = 100;

    printf("\n*****Welcome to FastSudokuGen. Note, F.A.S.T. (trademark pending) feature requires a CUDA capable GPU*****\n");
    //bool inputGood = true;

    char boxSizeString[STR_MAX];
    printf("\nPuzzles with what box size to generate? Enter a number between 2 and %d inclusive : ", MAX_BOX_SIZE);
    fgets(boxSizeString, STR_MAX, stdin);
    int boxSize = atoi(boxSizeString);
    if ((boxSize <= 1) || (boxSize > MAX_BOX_SIZE))
    {
        printf("\nPuzzle box size must be larger than 1 and not larger than 16!");
 

        printf("\n\nBad input, try again\n\n");
        return -1;
    }
    
    char puzzleNumString[STR_MAX];
    printf("\nHow many puzzles to generate? Enter a number greater than 0: ");
    fgets(puzzleNumString, STR_MAX, stdin);
    int puzzleNum = atoi(puzzleNumString);
    if (puzzleNum <= 0)
    {
        printf("\nNumber of puzzles must be greatern than 0");

        printf("\n\nBad input, try again\n\n");
        return -1;
    }

    char generatorTypeString[STR_MAX];
    printf("\nUse CUDA GPU? Enter y or n: ");
    fgets(generatorTypeString, STR_MAX, stdin);
    char cudaYesString[] = "y\n";
    int cudaYes = strcmp(cudaYesString, generatorTypeString);
    char cudaNoString[] = "n\n";
    int cudaNo = strcmp(cudaNoString, generatorTypeString);
    if ((cudaYes != 0) && (cudaNo != 0))
    {
        printf("\nEnter n for CPU generator or y for CUDA GPU generator n");

        printf("\n\nBad input, try again\n\n");
        return -1;
    }

    if(cudaNo == 0)
    {
        sudokuGenCPU(boxSize, puzzleNum);
    }

    else if (cudaYes == 0)
    {
        sudokuGenCPU(boxSize, puzzleNum);
    }


    printf("\n\n");
    return 0;
}