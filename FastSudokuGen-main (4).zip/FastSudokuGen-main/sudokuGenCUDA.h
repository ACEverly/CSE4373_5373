#ifndef SUDOKUGENCUDA_H
#define SUDOKUGENCUDA_H

void sudokuGenCUDA(int puzzleNum, int boxSize);

#endif